// ═══════════════════════════════════════════
// data.js — Configuración de Supabase y datos
// ═══════════════════════════════════════════

// ── Configuración de Supabase ──────────────
// Reemplaza con tus credenciales reales del proyecto
const SUPABASE_URL  = 'https://TU_PROYECTO.supabase.co'
const SUPABASE_ANON = 'TU_ANON_KEY'

// Inicializar cliente (disponible globalmente)
// Se usa la variable global que expone el CDN de Supabase
const { createClient } = supabase
const db = createClient(SUPABASE_URL, SUPABASE_ANON)

// ── Número de mesa ──────────────────────────
// Se obtiene de la URL: ?mesa=3
// Si no hay parámetro, queda como null (pedido desde kiosco general)
const urlParams  = new URLSearchParams(window.location.search)
const MESA_ACTUAL = urlParams.get('mesa') || null

// ── Datos de demostración ──────────────────
// Mientras conectas Supabase, el sistema usa estos datos.
// Cuando la tabla `productos` tenga datos, se reemplaza automáticamente.
const MENU_DEMO = [
  {
    id: 1,
    nombre: 'Mofongo de camarones',
    descripcion: 'Plátano verde majado con ajo, chicharrón y camarones al ajillo',
    precio: 595,
    categoria: 'Platos fuertes',
    imagen_url: null,
    disponible: true,
    destacado: true,
  },
  {
    id: 2,
    nombre: 'Tostones con queso',
    descripcion: 'Crujientes tostones con queso blanco y salsa rosada',
    precio: 220,
    categoria: 'Entradas',
    imagen_url: null,
    disponible: true,
    destacado: false,
  },
  {
    id: 3,
    nombre: 'Pollo guisado',
    descripcion: 'Muslo de pollo criollo con arroz blanco y habichuelas',
    precio: 450,
    categoria: 'Platos fuertes',
    imagen_url: null,
    disponible: true,
    destacado: false,
  },
  {
    id: 4,
    nombre: 'Jugo de chinola',
    descripcion: 'Maracuyá fresco con agua o leche, sin azúcar añadida',
    precio: 120,
    categoria: 'Bebidas',
    imagen_url: null,
    disponible: true,
    destacado: false,
  },
  {
    id: 5,
    nombre: 'Ceviche de pargo',
    descripcion: 'Pargo fresco marinado en limón con cebolla roja y cilantro',
    precio: 480,
    categoria: 'Entradas',
    imagen_url: null,
    disponible: true,
    destacado: true,
  },
  {
    id: 6,
    nombre: 'Flan de coco',
    descripcion: 'Flan artesanal de coco tostado con caramelo oscuro',
    precio: 195,
    categoria: 'Postres',
    imagen_url: null,
    disponible: true,
    destacado: false,
  },
  {
    id: 7,
    nombre: 'Agua de Jamaica',
    descripcion: 'Infusión de flor de hibiscus, refrescante y natural',
    precio: 95,
    categoria: 'Bebidas',
    imagen_url: null,
    disponible: true,
    destacado: false,
  },
  {
    id: 8,
    nombre: 'Chivo guisado',
    descripcion: 'Estofado criollo de chivo con batata y vegetales de temporada',
    precio: 620,
    categoria: 'Platos fuertes',
    imagen_url: null,
    disponible: false, // ejemplo de producto no disponible
    destacado: false,
  },
]

// ── Emojis de fallback por categoría ──────
const EMOJI_CATEGORIA = {
  'Entradas':       '🥗',
  'Platos fuertes': '🍽️',
  'Bebidas':        '🥤',
  'Postres':        '🍮',
  'default':        '🍴',
}
