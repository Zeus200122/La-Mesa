// ═══════════════════════════════════════════
// app.js — Lógica principal de la pantalla del cliente
// ═══════════════════════════════════════════

// ── Estado global ──────────────────────────
const state = {
  productos:        [],        // todos los productos cargados
  categoriaActiva:  'Todos',   // filtro activo
  carrito:          [],        // [{ producto, cantidad }]
}

// ── Referencias al DOM ─────────────────────
const $ = (id) => document.getElementById(id)

const elMesaNum     = $('mesa-numero')
const elCategorias  = $('categorias')
const elMenuGrid    = $('menu-grid')
const elCartToggle  = $('cart-toggle')
const elCartBadge   = $('cart-badge')
const elCartPanel   = $('cart-panel')
const elCartOverlay = $('cart-overlay')
const elCartClose   = $('cart-close')
const elCartList    = $('cart-list')
const elCartEmpty   = $('cart-empty')
const elCartTotal   = $('cart-total')
const elBtnConfirmar = $('btn-confirmar')
const elNotaPedido  = $('nota-pedido')
const elModalConfirm = $('modal-confirm')
const elConfirmNum  = $('confirm-num')
const elModalClose  = $('modal-close')

// ════════════════════════════════════════════
// INICIALIZACIÓN
// ════════════════════════════════════════════
async function init() {
  mostrarMesa()
  const productos = await cargarProductos()
  state.productos = productos
  renderCategorias()
  renderMenu()
  bindEvents()
}

// ── Mostrar número de mesa ─────────────────
function mostrarMesa() {
  elMesaNum.textContent = MESA_ACTUAL ?? '—'
}

// ── Cargar productos desde Supabase ────────
// Si falla (credenciales no configuradas), usa MENU_DEMO
async function cargarProductos() {
  // Verificar si las credenciales están configuradas
  if (SUPABASE_URL.includes('TU_PROYECTO')) {
    console.info('[demo] Usando datos de demostración. Configura SUPABASE_URL en data.js.')
    return MENU_DEMO
  }

  try {
    const { data, error } = await db
      .from('productos')
      .select('*')
      .eq('disponible', true)
      .order('categoria')

    if (error) throw error
    return data
  } catch (err) {
    console.warn('[supabase] Error al cargar productos, usando demo:', err.message)
    return MENU_DEMO
  }
}

// ════════════════════════════════════════════
// RENDER — CATEGORÍAS
// ════════════════════════════════════════════
function renderCategorias() {
  const cats = ['Todos', ...new Set(state.productos.map(p => p.categoria))]

  elCategorias.innerHTML = cats.map(cat => `
    <button
      class="cat-btn${cat === state.categoriaActiva ? ' active' : ''}"
      data-cat="${cat}"
      aria-pressed="${cat === state.categoriaActiva}"
    >
      ${cat}
    </button>
  `).join('')
}

// ════════════════════════════════════════════
// RENDER — GRID DE PRODUCTOS
// ════════════════════════════════════════════
function renderMenu() {
  const filtrados = state.categoriaActiva === 'Todos'
    ? state.productos.filter(p => p.disponible)
    : state.productos.filter(p => p.categoria === state.categoriaActiva && p.disponible)

  if (filtrados.length === 0) {
    elMenuGrid.innerHTML = '<p class="menu-empty">No hay productos en esta categoría.</p>'
    return
  }

  elMenuGrid.innerHTML = filtrados.map((p, i) => `
    <article
      class="card"
      style="animation-delay: ${i * 0.04}s"
      data-id="${p.id}"
    >
      <div class="card__img-wrap">
        ${p.imagen_url
          ? `<img src="${p.imagen_url}" alt="${p.nombre}" loading="lazy" />`
          : `<div class="card__placeholder">${EMOJI_CATEGORIA[p.categoria] ?? EMOJI_CATEGORIA.default}</div>`
        }
        ${p.destacado ? '<span class="card__tag">Destacado</span>' : ''}
      </div>
      <div class="card__body">
        <p class="card__name">${p.nombre}</p>
        <p class="card__desc">${p.descripcion}</p>
        <div class="card__footer">
          <span class="card__price">RD$${p.precio.toLocaleString('es-DO')}</span>
          <button
            class="card__add"
            data-id="${p.id}"
            aria-label="Agregar ${p.nombre} al pedido"
          >+</button>
        </div>
      </div>
    </article>
  `).join('')
}

// ════════════════════════════════════════════
// CARRITO
// ════════════════════════════════════════════

// ── Agregar producto ───────────────────────
function agregarAlCarrito(id) {
  const producto = state.productos.find(p => p.id === id)
  if (!producto) return

  const existente = state.carrito.find(i => i.producto.id === id)
  if (existente) {
    existente.cantidad += 1
  } else {
    state.carrito.push({ producto, cantidad: 1 })
  }

  actualizarCarritoUI()
  animarBotonAdd(id)
}

// ── Cambiar cantidad ───────────────────────
function cambiarCantidad(id, delta) {
  const idx = state.carrito.findIndex(i => i.producto.id === id)
  if (idx === -1) return

  state.carrito[idx].cantidad += delta

  if (state.carrito[idx].cantidad <= 0) {
    state.carrito.splice(idx, 1)
  }

  actualizarCarritoUI()
}

// ── Actualizar toda la UI del carrito ──────
function actualizarCarritoUI() {
  const total       = calcularTotal()
  const cantTotal   = state.carrito.reduce((s, i) => s + i.cantidad, 0)
  const carritoVacio = state.carrito.length === 0

  // Badge
  elCartBadge.textContent = cantTotal
  elCartBadge.classList.toggle('visible', cantTotal > 0)

  // Estado vacío
  elCartEmpty.classList.toggle('visible', carritoVacio)

  // Botón confirmar
  elBtnConfirmar.disabled = carritoVacio

  // Total
  elCartTotal.textContent = `RD$${total.toLocaleString('es-DO')}`

  // Lista
  if (carritoVacio) {
    elCartList.innerHTML = ''
    return
  }

  elCartList.innerHTML = state.carrito.map(item => `
    <li class="cart-item" data-id="${item.producto.id}">
      <span class="cart-item__name">${item.producto.nombre}</span>
      <div class="cart-item__controls">
        <button class="cart-item__qty-btn" data-action="menos" data-id="${item.producto.id}" aria-label="Quitar uno">−</button>
        <span class="cart-item__qty">${item.cantidad}</span>
        <button class="cart-item__qty-btn" data-action="mas" data-id="${item.producto.id}" aria-label="Agregar uno">+</button>
      </div>
      <span class="cart-item__subtotal">RD$${(item.producto.precio * item.cantidad).toLocaleString('es-DO')}</span>
    </li>
  `).join('')
}

// ── Calcular total ─────────────────────────
function calcularTotal() {
  return state.carrito.reduce((sum, i) => sum + i.producto.precio * i.cantidad, 0)
}

// ── Animación de feedback al agregar ──────
function animarBotonAdd(id) {
  const btn = document.querySelector(`.card__add[data-id="${id}"]`)
  if (!btn) return
  btn.textContent = '✓'
  btn.style.background = 'var(--gold)'
  setTimeout(() => {
    btn.textContent = '+'
    btn.style.background = ''
  }, 700)
}

// ════════════════════════════════════════════
// CONFIRMAR PEDIDO → SUPABASE
// ════════════════════════════════════════════
async function confirmarPedido() {
  if (state.carrito.length === 0) return

  elBtnConfirmar.textContent = 'Enviando…'
  elBtnConfirmar.classList.add('loading')

  const payload = {
    mesa:        MESA_ACTUAL,
    nota:        elNotaPedido.value.trim() || null,
    total:       calcularTotal(),
    estado:      'pendiente',
    items: state.carrito.map(i => ({
      producto_id: i.producto.id,
      nombre:      i.producto.nombre,
      precio:      i.producto.precio,
      cantidad:    i.cantidad,
    })),
  }

  try {
    // Si Supabase no está configurado, simular éxito
    if (SUPABASE_URL.includes('TU_PROYECTO')) {
      await new Promise(r => setTimeout(r, 1000)) // simular latencia
      mostrarConfirmacion('DEMO-' + Date.now().toString().slice(-4))
      return
    }

    const { data, error } = await db
      .from('pedidos')
      .insert(payload)
      .select('id')
      .single()

    if (error) throw error
    mostrarConfirmacion(data.id)

  } catch (err) {
    console.error('[supabase] Error al enviar pedido:', err)
    alert('Hubo un problema al enviar tu pedido. Por favor avisa a un empleado.')
  } finally {
    elBtnConfirmar.textContent = 'Confirmar pedido'
    elBtnConfirmar.classList.remove('loading')
  }
}

// ════════════════════════════════════════════
// MODAL DE CONFIRMACIÓN
// ════════════════════════════════════════════
function mostrarConfirmacion(pedidoId) {
  cerrarCarrito()

  // Limpiar estado
  state.carrito = []
  elNotaPedido.value = ''
  actualizarCarritoUI()

  // Mostrar modal
  elConfirmNum.textContent = `Pedido #${pedidoId}`
  elModalConfirm.classList.add('open')
  elModalConfirm.setAttribute('aria-hidden', 'false')
}

function cerrarModal() {
  elModalConfirm.classList.remove('open')
  elModalConfirm.setAttribute('aria-hidden', 'true')
}

// ════════════════════════════════════════════
// PANEL DEL CARRITO (abrir/cerrar)
// ════════════════════════════════════════════
function abrirCarrito() {
  elCartPanel.classList.add('open')
  elCartPanel.setAttribute('aria-hidden', 'false')
  document.body.style.overflow = 'hidden'
}

function cerrarCarrito() {
  elCartPanel.classList.remove('open')
  elCartPanel.setAttribute('aria-hidden', 'true')
  document.body.style.overflow = ''
}

// ════════════════════════════════════════════
// EVENTOS
// ════════════════════════════════════════════
function bindEvents() {
  // Filtros de categoría (delegación)
  elCategorias.addEventListener('click', (e) => {
    const btn = e.target.closest('.cat-btn')
    if (!btn) return
    state.categoriaActiva = btn.dataset.cat

    // Actualizar botones activos
    elCategorias.querySelectorAll('.cat-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.cat === state.categoriaActiva)
      b.setAttribute('aria-pressed', b.dataset.cat === state.categoriaActiva)
    })

    renderMenu()
  })

  // Agregar al carrito (delegación en el grid)
  elMenuGrid.addEventListener('click', (e) => {
    const btn = e.target.closest('.card__add')
    if (!btn) return
    agregarAlCarrito(Number(btn.dataset.id))
  })

  // Controles del carrito (delegación)
  elCartList.addEventListener('click', (e) => {
    const btn = e.target.closest('.cart-item__qty-btn')
    if (!btn) return
    const id    = Number(btn.dataset.id)
    const delta = btn.dataset.action === 'mas' ? 1 : -1
    cambiarCantidad(id, delta)
  })

  // Abrir/cerrar carrito
  elCartToggle.addEventListener('click', abrirCarrito)
  elCartClose.addEventListener('click', cerrarCarrito)
  elCartOverlay.addEventListener('click', cerrarCarrito)

  // Confirmar pedido
  elBtnConfirmar.addEventListener('click', confirmarPedido)

  // Cerrar modal
  elModalClose.addEventListener('click', cerrarModal)

  // Cerrar modal con Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (elModalConfirm.classList.contains('open')) cerrarModal()
      else cerrarCarrito()
    }
  })
}

// ════════════════════════════════════════════
// ARRANQUE
// ════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', init)
